import UIKit

final class WishMakerViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        configureUI()
    }

    private func configureUI() {
        view.backgroundColor = .black
        configureTitle()
        configureDescription()
        configureSliders()
    }
    static let title = UILabel()
   
    private func configureTitle() {
        WishMakerViewController.title.translatesAutoresizingMaskIntoConstraints = false
        WishMakerViewController.title.text = "WishMaker"
        WishMakerViewController.title.font = UIFont.boldSystemFont(ofSize: 32)
        WishMakerViewController.title.textColor = .white
        WishMakerViewController.title.textAlignment = .center
        view.addSubview(WishMakerViewController.title)
        NSLayoutConstraint.activate([
            WishMakerViewController.title.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            WishMakerViewController.title.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            WishMakerViewController.title.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 30)
        ])
        
    }
    func configureDescription() {
        let description = UILabel()
        description.translatesAutoresizingMaskIntoConstraints = false
        description.text = "The description of WishMaker"
        description.font = UIFont.boldSystemFont(ofSize: 14)
        description.textColor = .systemBrown
        view.addSubview(description)
        
        NSLayoutConstraint.activate([
            description.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            description.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            description.bottomAnchor.constraint(equalTo: WishMakerViewController.title.bottomAnchor, constant: 20)
           
        ])
    }
    
    final class CustomSlider: UIView {
        var valueChanged: ((Double) -> Void)?

        var slider = UISlider()
        var titleView = UILabel()

        init(title: String, min: Double, max: Double) {
            super.init(frame: .zero)
            
            titleView.text = title
            slider.minimumValue = Float(min)
            slider.maximumValue = Float(max)
            slider.addTarget(self, action: #selector(sliderValueChanged), for: .valueChanged)
            configureUI()
        }

        @available(*, unavailable)
        required init?(coder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }

        private func configureUI() {
            backgroundColor = .white
            translatesAutoresizingMaskIntoConstraints = false
            
            for view in [slider, titleView] {
                addSubview(view)
                view.translatesAutoresizingMaskIntoConstraints = false
            }
            
            NSLayoutConstraint.activate([
                titleView.centerXAnchor.constraint(equalTo: centerXAnchor),
                titleView.topAnchor.constraint(equalTo: topAnchor, constant: 10),
                titleView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
                
                slider.topAnchor.constraint(equalTo: titleView.bottomAnchor),
                slider.centerXAnchor.constraint(equalTo: centerXAnchor),
                slider.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -10),
                slider.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20)
            ])
        }

    @objc
    private func sliderValueChanged() {
        valueChanged?(Double(slider.value))
    }
    }
    enum Constants {
        static let sliderMax: Double = 1
        static let sliderMin: Double = 0
        
        static let red: String = "Red"
        static let green: String = "Green"
        static let blue: String = "Blue"
        
        static let stackRadius: CGFloat = 20
        static let stackBottom: CGFloat = -40
        static let stackLeading: CGFloat = 20
        
        static let baseValue: CGFloat = 0
    }
    private func configureSliders() {
        let stack = UIStackView()
        stack.translatesAutoresizingMaskIntoConstraints = false
        stack.axis = .vertical
        view.addSubview(stack)
        stack.layer.cornerRadius = Constants.stackRadius
        stack.clipsToBounds = true

        let sliderRed = CustomSlider(title: Constants.red, min: Constants.sliderMin, max: Constants.sliderMax)
        let sliderBlue = CustomSlider(title: Constants.blue, min: Constants.sliderMin, max: Constants.sliderMax)
        let sliderGreen = CustomSlider(title: Constants.green, min: Constants.sliderMin, max: Constants.sliderMax)

        for slider in [sliderRed, sliderBlue, sliderGreen] {
            stack.addArrangedSubview(slider)
        }

        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: Constants.stackLeading),
            stack.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: Constants.stackBottom)
        ])
        var red: CGFloat = Constants.baseValue
        var green: CGFloat = Constants.baseValue
        var blue: CGFloat = Constants.baseValue
        
        sliderRed.valueChanged = { [weak self] value in
            red = CGFloat(value)
            self?.view.backgroundColor = UIColor(red: CGFloat(value), green: green, blue: blue, alpha: 1)
        }
        sliderGreen.valueChanged = { [weak self] value in
            green = CGFloat(value)
            self?.view.backgroundColor = UIColor(red: red, green: CGFloat(value), blue: blue, alpha: 1)
        }
        sliderBlue.valueChanged = { [weak self] value in
            blue = CGFloat(value)
            self?.view.backgroundColor = UIColor(red: red, green: green, blue: CGFloat(value), alpha: 1)
        }
    }
}
